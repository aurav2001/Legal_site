<?php
/**
 * Template Name: Contact Us (AGL Style)
 *
 * Description: Law firm office, Supreme Court chambers, and confidential inquiry form.
 * Fully editable via WordPress Admin (Theme Options > Chambers & Contact + Page Editor).
 *
 * @package Legal_Insights
 */

get_header();

// If page is edited with Elementor, render full-width content directly
if (function_exists('legal_insights_is_elementor_page') && legal_insights_is_elementor_page()) {
    echo '<main id="primary" class="site-main elementor-contact-content" style="width: 100%;">';
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
    echo '</main>';
    get_footer();
    return;
}

$page_id = get_the_ID();
$tagline    = get_post_meta($page_id, '_contact_tagline', true);
$form_title = get_post_meta($page_id, '_contact_form_title', true);
$form_sub   = get_post_meta($page_id, '_contact_form_sub', true);

if (empty($tagline)) {
    $tagline = 'Chambers Engagement';
}
if (empty($form_title)) {
    $form_title = 'Confidential Inquiries';
}
if (empty($form_sub)) {
    $form_sub = 'All communications are covered by strict statutory advocate-client privilege.';
}

// Office Settings from Theme Options
$off_title  = function_exists('legal_insights_get_option') ? legal_insights_get_option('office_title', 'Principal Chambers') : 'Principal Chambers';
$off_badge  = function_exists('legal_insights_get_option') ? legal_insights_get_option('office_badge', 'Head Office') : 'Head Office';
$off_addr   = function_exists('legal_insights_get_option') ? legal_insights_get_option('office_address', 'B-33, 1st Floor, Jangpura Extension, New Delhi – 110014') : 'B-33, 1st Floor, Jangpura Extension, New Delhi – 110014';
$off_phone  = function_exists('legal_insights_get_option') ? legal_insights_get_option('office_phone', '+91 90135 35766') : '+91 90135 35766';
$off_email  = function_exists('legal_insights_get_option') ? legal_insights_get_option('office_email', 'chaitanyamlegal@gmail.com') : 'chaitanyamlegal@gmail.com';
$off_maps   = function_exists('legal_insights_get_option') ? legal_insights_get_option('office_maps_url', 'https://maps.app.goo.gl/pLAPAMtfgz7hAWnT9') : 'https://maps.app.goo.gl/pLAPAMtfgz7hAWnT9';

// Chambers Settings from Theme Options
$chamb_title = function_exists('legal_insights_get_option') ? legal_insights_get_option('chambers_title', 'Court Chambers') : 'Court Chambers';
$chamb_badge = function_exists('legal_insights_get_option') ? legal_insights_get_option('chambers_badge', 'Appellate Chambers') : 'Appellate Chambers';
$chamb_addr  = function_exists('legal_insights_get_option') ? legal_insights_get_option('chambers_address', "Supreme Court of India & High Court of Delhi Bar Chambers, New Delhi") : "Supreme Court of India & High Court of Delhi Bar Chambers, New Delhi";
$chamb_phone = function_exists('legal_insights_get_option') ? legal_insights_get_option('chambers_phone', '+91 90135 35766') : '+91 90135 35766';
$chamb_email = function_exists('legal_insights_get_option') ? legal_insights_get_option('chambers_email', 'chaitanyamlegal@gmail.com') : 'chaitanyamlegal@gmail.com';
$chamb_maps  = function_exists('legal_insights_get_option') ? legal_insights_get_option('chambers_maps_url', 'https://maps.app.goo.gl/pLAPAMtfgz7hAWnT9') : 'https://maps.app.goo.gl/pLAPAMtfgz7hAWnT9';
?>

<!-- Banner Section -->
<section class="about-mn">
    <div class="container-custom">
        <div class="about-banner">
            <div class="about_banner_txt" data-aos="fade-right">
                <div class="bnr_tag"><?php echo esc_html($tagline); ?></div>
                <h1 class="bnr_heading"><?php the_title(); ?></h1>
                <p class="bnr_subtitle">
                    Connect directly with our designated Senior Advocates and Partners at our Supreme Court Chambers and Central New Delhi Offices.
                </p>
            </div>
        </div>
    </div>
</section>

<?php
// Render Content from WordPress Page Editor if present
if (function_exists('legal_insights_render_page_content')) {
    legal_insights_render_page_content();
}
?>

<!-- Office & Chambers Cards Section -->
<section style="padding: 70px 0 90px 0; background: #fbfbfd;">
    <div class="container-custom">
        
        <div class="contact-offices-grid" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 40px; margin-bottom: 60px;">
            
            <!-- Office Card -->
            <div style="background: #ffffff; border: 1px solid var(--border-card); border-radius: var(--card-radius-curve); padding: 38px; box-shadow: 0 6px 20px rgba(51, 39, 32, 0.06); position: relative; overflow: hidden;" data-aos="fade-right">
                <span style="font-size: 0.8rem; font-weight: 700; color: var(--color-gold); letter-spacing: 0.12em; text-transform: uppercase; display: block; margin-bottom: 6px;">
                    <?php echo esc_html($off_badge); ?>
                </span>
                <h2 style="font-family: var(--font-serif); font-size: 1.8rem; color: var(--color-dark); margin-bottom: 16px;">
                    <?php echo esc_html($off_title); ?>
                </h2>
                <p style="font-size: 1rem; color: #554a43; line-height: 1.7; margin-bottom: 12px;">
                    <?php echo nl2br(esc_html($off_addr)); ?>
                </p>
                <p style="font-size: 0.95rem; color: #554a43; margin-bottom: 12px;">
                    <strong>Telephone: </strong><?php echo esc_html($off_phone); ?>
                </p>
                <p style="font-size: 0.95rem; color: #554a43; margin-bottom: 24px;">
                    <strong>Email: </strong><a href="mailto:<?php echo esc_attr($off_email); ?>" style="color: var(--color-gold); font-weight: 600;"><?php echo esc_html($off_email); ?></a>
                </p>
                <a href="<?php echo esc_url($off_maps); ?>" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; gap: 8px; font-size: 0.92rem; font-weight: 600; color: var(--color-dark); text-decoration: underline;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <span>Find Us on Google Maps</span>
                </a>
                <div class="bggrdnt"></div>
            </div>

            <!-- Court Chambers Card -->
            <div style="background: #ffffff; border: 1px solid var(--border-card); border-radius: var(--card-radius-curve); padding: 38px; box-shadow: 0 6px 20px rgba(51, 39, 32, 0.06); position: relative; overflow: hidden;" data-aos="fade-left">
                <span style="font-size: 0.8rem; font-weight: 700; color: var(--color-gold); letter-spacing: 0.12em; text-transform: uppercase; display: block; margin-bottom: 6px;">
                    <?php echo esc_html($chamb_badge); ?>
                </span>
                <h2 style="font-family: var(--font-serif); font-size: 1.8rem; color: var(--color-dark); margin-bottom: 16px;">
                    <?php echo esc_html($chamb_title); ?>
                </h2>
                <p style="font-size: 1rem; color: #554a43; line-height: 1.7; margin-bottom: 12px;">
                    <?php echo nl2br(esc_html($chamb_addr)); ?>
                </p>
                <p style="font-size: 0.95rem; color: #554a43; margin-bottom: 12px;">
                    <strong>Telephone: </strong><?php echo esc_html($chamb_phone); ?>
                </p>
                <p style="font-size: 0.95rem; color: #554a43; margin-bottom: 24px;">
                    <strong>Email: </strong><a href="mailto:<?php echo esc_attr($chamb_email); ?>" style="color: var(--color-gold); font-weight: 600;"><?php echo esc_html($chamb_email); ?></a>
                </p>
                <a href="<?php echo esc_url($chamb_maps); ?>" target="_blank" rel="noopener noreferrer" style="display: inline-flex; align-items: center; gap: 8px; font-size: 0.92rem; font-weight: 600; color: var(--color-dark); text-decoration: underline;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <span>View Supreme Court Chambers Location</span>
                </a>
                <div class="bggrdnt"></div>
            </div>

        </div>

        <!-- Confidential Inquiry Form -->
        <div class="contact-form-box" style="background: #ffffff; border: 1px solid var(--border-card-subtle); border-radius: var(--card-radius-curve); box-shadow: 0 8px 30px rgba(51, 39, 32, 0.05); max-width: 900px; margin: 0 auto; padding: 50px 48px;" data-aos="fade-up">
            <div style="text-align: center; margin-bottom: 36px;">
                <span style="font-size: 0.8rem; font-weight: 700; color: var(--color-gold); letter-spacing: 0.15em; text-transform: uppercase; display: block; margin-bottom: 6px;">
                    Advocate-Client Intake Protocol
                </span>
                <h2 style="font-family: var(--font-serif); font-size: 2.2rem; color: var(--color-dark); margin-bottom: 10px;">
                    <?php echo esc_html($form_title); ?>
                </h2>
                <p style="font-size: 0.95rem; color: #64748b; max-width: 600px; margin: 0 auto;">
                    <?php echo esc_html($form_sub); ?>
                </p>
            </div>

            <!-- Dynamic AJAX Alert Container -->
            <div id="inquiryAlert" style="display: none; margin-bottom: 28px; border-radius: 8px; padding: 18px 24px; font-size: 0.95rem; line-height: 1.6;"></div>

            <form id="legalInquiryForm" class="contact-form-grid" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 22px;">
                <!-- Security Honeypot to Trap Automated Spam Bots -->
                <div style="display:none !important; position:absolute; left:-9999px;" aria-hidden="true">
                    <input type="text" name="legal_fax_verify" tabindex="-1" autocomplete="off">
                </div>
                <div>
                    <label for="client_name" style="display: block; font-size: 0.85rem; font-weight: 600; color: var(--color-dark); margin-bottom: 8px;">Your Full Name *</label>
                    <input type="text" name="client_name" id="client_name" required placeholder="e.g. Alok Sharma" style="width: 100%; padding: 12px 16px; border: 1px solid #deddda; border-radius: 8px; font-family: var(--font-sans); outline: none; font-size: 0.95rem;">
                </div>
                <div>
                    <label for="client_email" style="display: block; font-size: 0.85rem; font-weight: 600; color: var(--color-dark); margin-bottom: 8px;">Official Email *</label>
                    <input type="email" name="client_email" id="client_email" required placeholder="name@company.com" style="width: 100%; padding: 12px 16px; border: 1px solid #deddda; border-radius: 8px; font-family: var(--font-sans); outline: none; font-size: 0.95rem;">
                </div>
                <div>
                    <label for="client_phone" style="display: block; font-size: 0.85rem; font-weight: 600; color: var(--color-dark); margin-bottom: 8px;">Contact Number *</label>
                    <input type="tel" name="client_phone" id="client_phone" required placeholder="+91 98110 00000" style="width: 100%; padding: 12px 16px; border: 1px solid #deddda; border-radius: 8px; font-family: var(--font-sans); outline: none; font-size: 0.95rem;">
                </div>
                <div>
                    <label for="practice_jurisdiction" style="display: block; font-size: 0.85rem; font-weight: 600; color: var(--color-dark); margin-bottom: 8px;">Practice Area / Jurisdiction</label>
                    <select name="practice_jurisdiction" id="practice_jurisdiction" style="width: 100%; padding: 12px 16px; border: 1px solid #deddda; border-radius: 8px; font-family: var(--font-sans); outline: none; background: #ffffff; font-size: 0.95rem;">
                        <option value="Arbitration & ADR">Arbitration &amp; ADR</option>
                        <option value="Commercial Litigation">Commercial Litigation</option>
                        <option value="Corporate & Insolvency Laws">Corporate &amp; Insolvency Laws (IBC)</option>
                        <option value="Competition Law">Competition Law (CCI)</option>
                        <option value="Constitutional Law">Constitutional Law</option>
                        <option value="White-Collar Crime">White-Collar Crime (PMLA / ED)</option>
                        <option value="Taxation & Regulatory Affairs">Taxation &amp; Regulatory Affairs</option>
                        <option value="Other High Court / SC Mandate">Other High Court / Supreme Court Mandate</option>
                    </select>
                </div>
                <div>
                    <label for="court_forum" style="display: block; font-size: 0.85rem; font-weight: 600; color: var(--color-dark); margin-bottom: 8px;">Target Judicial Forum</label>
                    <select name="court_forum" id="court_forum" style="width: 100%; padding: 12px 16px; border: 1px solid #deddda; border-radius: 8px; font-family: var(--font-sans); outline: none; background: #ffffff; font-size: 0.95rem;">
                        <option value="Supreme Court of India">Supreme Court of India (Apex Court)</option>
                        <option value="Delhi High Court">Delhi High Court (Appellate / Original)</option>
                        <option value="Other State High Court">Other State High Court</option>
                        <option value="NCLAT / NCLT">NCLT / NCLAT (Corporate & Insolvency)</option>
                        <option value="CCI / Appellate Tribunal">CCI (Competition Commission)</option>
                        <option value="Arbitration Tribunal">Domestic / International Arbitral Tribunal</option>
                        <option value="Trial / Special Sessions Court">Special Sessions Court (PMLA / CBI)</option>
                    </select>
                </div>
                <div>
                    <label for="urgency_level" style="display: block; font-size: 0.85rem; font-weight: 600; color: var(--color-dark); margin-bottom: 8px;">Matter Urgency</label>
                    <select name="urgency_level" id="urgency_level" style="width: 100%; padding: 12px 16px; border: 1px solid #deddda; border-radius: 8px; font-family: var(--font-sans); outline: none; background: #ffffff; font-size: 0.95rem;">
                        <option value="Normal">Normal (Standard Review &amp; Consultation)</option>
                        <option value="High">⚡ High (Upcoming Hearing / Impending Order)</option>
                        <option value="Emergency (24-48 Hours)">🚨 Emergency (Urgent Mentioning / Stay / Bail)</option>
                    </select>
                </div>
                <div style="grid-column: 1 / -1;">
                    <label for="legal_mandate" style="display: block; font-size: 0.85rem; font-weight: 600; color: var(--color-dark); margin-bottom: 8px;">Brief Outline of Legal Mandate *</label>
                    <textarea name="legal_mandate" id="legal_mandate" rows="4" required placeholder="Please summarize the key factual dispute, ongoing legal proceedings (if any), and specific reliefs sought..." style="width: 100%; padding: 14px 16px; border: 1px solid #deddda; border-radius: 8px; font-family: var(--font-sans); outline: none; font-size: 0.95rem;"></textarea>
                </div>
                <div style="grid-column: 1 / -1; text-align: center; margin-top: 10px;">
                    <button type="submit" id="inquirySubmitBtn" style="background: linear-gradient(135deg, #c5a059 0%, #dfba73 50%, #b38b42 100%); color: #0b111e; font-weight: 700; font-size: 1rem; padding: 15px 44px; border: none; border-radius: 8px; cursor: pointer; box-shadow: 0 4px 18px rgba(197, 160, 89, 0.4); display: inline-flex; align-items: center; justify-content: center; gap: 10px; transition: all 0.25s ease;">
                        <span class="btn-text">Transmit Privileged Mandate &rarr;</span>
                        <span class="btn-spinner" style="display: none;">⏳ Transmitting Privileged Mandate...</span>
                    </button>
                    <p style="font-size: 0.82rem; color: #94a3b8; margin-top: 16px; margin-bottom: 0;">
                        🔒 <em>Strict Professional Secrecy: Transmissions are covered under Section 126 of the Indian Evidence Act.</em>
                    </p>
                </div>
            </form>
        </div>

    </div>
</section>

<?php get_footer(); ?>
